/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserControllers;

import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "UserAddController", urlPatterns = {"/UserAddController"})
public class UserAddController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String role = request.getParameter("role");

        try {

            PreparedStatement pst;
            Connection con = null;

            try {
                con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/suppliermanagement", "root", "");
            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
                out.println("" + ex);
            }
            pst = con.prepareStatement("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)");

            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, email);
            pst.setString(4, role);

            pst.executeUpdate();

            request.setAttribute("info_Message", "Added Successfull...");
            request.getRequestDispatcher("/users/users.jsp").forward(request, response);

//                out.println("SUCESS!!");
//               response.sendRedirect("index.jsp");
        } catch (SQLException ex) {
            request.setAttribute("info_Message", "" + ex);
            request.getRequestDispatcher("/users/users.jsp").forward(request, response);
        }
    }

}
