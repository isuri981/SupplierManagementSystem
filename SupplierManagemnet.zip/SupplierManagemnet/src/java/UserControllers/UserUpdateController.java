/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserControllers;

import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "UserUpdateController", urlPatterns = {"/UserUpdateController"})
public class UserUpdateController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        String id = request.getParameter("id");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String role = request.getParameter("role");

        try {

            PreparedStatement pst;
            Connection con = null;

            try {
                con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/suppliermanagement", "root", "");
            } catch (ClassNotFoundException ex) {
                request.setAttribute("info_Message", "1 " + ex);

                request.getRequestDispatcher("/users/users.jsp").forward(request, response);
            }
            pst = con.prepareStatement("UPDATE users set username= ?, email = ?, role = ? WHERE id = ?");

            pst.setString(1, username);
            pst.setString(2, email);
            pst.setString(3, role);
            pst.setString(4, id);
            pst.executeUpdate();

            request.setAttribute("info_Message", "Successfull...");

            request.getRequestDispatcher("/users/users.jsp").forward(request, response);

        } catch (SQLException ex) {
            request.setAttribute("info_Message", "2 " + ex);

            request.getRequestDispatcher("/users/users.jsp").forward(request, response);
        }
    }

}
