/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProductController;

import UserControllers.*;
import Controller.*;
import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "ProductDeleteController", urlPatterns = {"/ProductDeleteController"})
public class ProductDeleteController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        String id = request.getParameter("id");
        

        try {
            

            PreparedStatement pst;
            Connection con = null;

            try {
                con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/suppliermanagement", "root", "");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
            }
            pst = con.prepareStatement("DELETE From product where product_id = ? ");

            pst.setString(1, id);
            
            pst.executeUpdate();

            request.setAttribute("info_Message", "Deleted");

            request.getRequestDispatcher("/product/Product.jsp").forward(request, response);

//                out.println("SUCESS!!");
//               response.sendRedirect("index.jsp");
        } catch (SQLException ex) {
            request.setAttribute("info_Message", ""+ex);

            request.getRequestDispatcher("/product/product.jsp").forward(request, response);

        }
    }
}
