/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "StDataController", urlPatterns = {"/StDataController"})
public class StDataController extends HttpServlet {

    
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        

      

           try{
                String st_id = request.getParameter("st_id");
                String name = request.getParameter("name");
                String age = request.getParameter("age");
                String dep = request.getParameter("dep");
                String fees = request.getParameter("fees");

                PreparedStatement pst;
                Connection con = null;

            try {
                con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/studentm", "root", "");
            } catch (ClassNotFoundException ex) {
                
            }
                pst = con.prepareStatement("INSERT INTO students(st_id,name,age,dep,fees) VALUES (?,?,?,?,?)");
                
                
                pst.setString(1, st_id);
                pst.setString(2, name);
                pst.setString(3, age);
                pst.setString(4, dep);
                pst.setString(5, fees);
                pst.executeUpdate();
                
               
               request.setAttribute("msg", "data sent");
               
               request.getRequestDispatcher("home.jsp").forward(request,response);
                
//                out.println("SUCESS!!");
//               response.sendRedirect("index.jsp");
                
            } catch (SQLException ex) {
               
            

                
            
            
        }
    }

    

}
