/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sun.security.util.Password;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "LogInController", urlPatterns = {"/LogInController"})
public class LogInController extends HttpServlet {

    // Function to hash the password using SHA-256 algorithm
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            return bytesToHex(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Function to convert bytes to hexadecimal string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        String Username = request.getParameter("username");
        String Password = request.getParameter("password");
        String hashedPassword = hashPassword(Password);

        try {
            PreparedStatement pst;
            Connection con = null;

            con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/suppliermanagement", "root", "");
            pst = con.prepareStatement("SELECT * FROM users WHERE username = ?");

            pst.setString(1, Username);

            ResultSet checkResult = pst.executeQuery();

            if (checkResult.next()) {
                String uname = checkResult.getString("username");
                String storedHashedPassword = checkResult.getString("password");
                String role = checkResult.getString("role");

                if (hashedPassword.equals(storedHashedPassword)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("UN", uname);
                    session.setAttribute("ROLE", role);
                    response.sendRedirect("index.jsp");
                }else{
                    request.setAttribute("Message", "Password Does not match");

                request.getRequestDispatcher("login.jsp").forward(request, response);
                }

            } else {
                request.setAttribute("Message", "User not found");

                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
            pst.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Signup.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LogInController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
