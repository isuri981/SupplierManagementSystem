/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuppliersController;

import Models.DBConnectionHelper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isuri Samaranayaka
 */
@WebServlet(name = "UpdateController", urlPatterns = {"/UpdateController"})
public class UpdateController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        String sup_id = request.getParameter("supplier_id");
        String sup_name = request.getParameter("supplier_name");
        String contact_person = request.getParameter("contact_person");
        String email = request.getParameter("email");
        String p_number = request.getParameter("phone_number");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String country = request.getParameter("country");
        String postal_code = request.getParameter("postal_code");

        try {

            PreparedStatement pst;
            Connection con = null;

            try {
                con = DBConnectionHelper.connectToDatabase("jdbc:mysql://localhost:3306/suppliermanagement", "root", "");
            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
                out.println("" + ex);
            }
            pst = con.prepareStatement("UPDATE supplier set supplier_name= ?, contact_person = ?, email= ?, phone_number= ?, address= ?, city= ?, country= ?, postal_code= ? WHERE supplier_id = ?");

            pst.setString(1, sup_name);
            pst.setString(2, contact_person);
            pst.setString(3, email);
            pst.setString(4, p_number);
            pst.setString(5, address);
            pst.setString(6, city);
            pst.setString(7, country);
            pst.setString(8, postal_code);
            pst.setString(9, sup_id);
            pst.executeUpdate();

            request.setAttribute("info_Message", "Successfull...");

            request.getRequestDispatcher("/suppliers/suppliers.jsp").forward(request, response);

//                out.println("SUCESS!!");
//               response.sendRedirect("index.jsp");
        } catch (SQLException ex) {
//            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
            out.println("" + ex);
        }
    }

}
